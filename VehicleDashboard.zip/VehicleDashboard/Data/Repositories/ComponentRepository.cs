﻿using System.Collections.Generic;
using System.Linq;
using VehicleDashboard.Models;

namespace VehicleDashboard.Data.Repositories
{
    public class ComponentRepository : IComponentRepository
    {
        VehicleDbContext dbContext;
        public ComponentRepository(VehicleDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
    
        public List<Brakes> GetBrakes()
        {
            return dbContext.Brakes.OrderBy(o => o.Cost).ToList();
        }

        public Brakes GetBrakesById(int id)
        {
            return dbContext.Brakes.Where(o => o.Id == id).First();
        }

        public Engine GetEngineById(int id)
        {
            return dbContext.Engines.Where(o => o.Id == id).First();
        }

        public List<Engine> GetEngines()
        {
            return dbContext.Engines.OrderBy(o => o.Cost).ToList();
        }

        public Transmission GetTransmissionById(int id)
        {
            return dbContext.Transmissions.Where(o => o.Id == id).First();
        }

        public List<Transmission> GetTransmissions()
        {
            return dbContext.Transmissions.OrderBy(o => o.Cost).ToList();
        }

        public Vehicle GetVehicleById(int id)
        {
            return dbContext.Vehicles.Where(o => o.Id == id).First();
        }

        public List<Vehicle> GetVehicles()
        {
            return dbContext.Vehicles.OrderBy(o => o.Cost).ToList();
        }

        public List<Wheels> GetWheels()
        {
            return dbContext.Wheels.OrderBy(o => o.Cost).ToList();
        }

        public Wheels GetWheelsById(int id)
        {
            return dbContext.Wheels.Where(o => o.Id == id).First();
        }
    }
}
