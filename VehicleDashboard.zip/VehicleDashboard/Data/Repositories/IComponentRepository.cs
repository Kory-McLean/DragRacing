﻿using System.Collections.Generic;
using VehicleDashboard.Models;

namespace VehicleDashboard.Data.Repositories
{
    public interface IComponentRepository
    {
        List<Vehicle> GetVehicles();
        List<Engine> GetEngines();
        List<Transmission> GetTransmissions();
        List<Wheels> GetWheels();
        List<Brakes> GetBrakes();
        Vehicle GetVehicleById(int id);
        Engine GetEngineById(int id);
        Transmission GetTransmissionById(int id);
        Brakes GetBrakesById(int id);
        Wheels GetWheelsById(int id);
    }
}
