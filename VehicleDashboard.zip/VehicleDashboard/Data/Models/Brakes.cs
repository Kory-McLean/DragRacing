﻿namespace VehicleDashboard.Models
{
    public class Brakes
    {
        public int Id { get; set; }
        public string ModelName { get; set; }
        public decimal MaxBrakeTorque { get; set; }
        public int Cost { get; set; }

    }
}
