﻿namespace VehicleDashboard.Models
{
    public class Vehicle
    {
        public int Id { get; set; }

        public string ModelName { get; set; }
        public decimal Mass { get; set; }
        public Engine Engine { get; set; }
        public Brakes BrakePads { get; set; }
        public Transmission Transmission { get; set; }
        public Wheels Wheels { get; set; }
        public int Cost { get; set; }
    }
}
