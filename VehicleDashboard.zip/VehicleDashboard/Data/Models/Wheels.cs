﻿namespace VehicleDashboard.Models
{
    public class Wheels
    {
        public int Id { get; set; }
        public string ModelName { get; set; }
        public decimal Diameter { get; set; }
        public int Cost { get; set; }
    }
}
