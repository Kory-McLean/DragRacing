﻿namespace VehicleDashboard.Models
{
    public class Engine
    {
        public int Id { get; set; }
        public string ModelName { get; set; }
        public decimal IdleRPM { get; set; }
        public decimal MaxRPM { get; set; }
        public decimal RedLineRPM { get; set; }
        public decimal MinTorque { get; set; }
        public decimal MaxTorque { get; set; }
        public int Cost { get; set; }
    }
}
