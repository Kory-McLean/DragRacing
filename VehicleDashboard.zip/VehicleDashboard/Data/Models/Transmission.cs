﻿using System.ComponentModel.DataAnnotations.Schema;

namespace VehicleDashboard.Models
{
    public class Transmission
    {
        public int Id { get; set; }
        public string ModelName { get; set; }
        [NotMapped]
        public decimal[] Gears = new decimal[] { 0M, 0.4M, 0.7M, 1.0M, 1.3M, 1.5M, 1.68M };
        public decimal Ratio { get; set; }
        public decimal Loss { get; set; }
        public int Cost { get; set; }
    }
}
