﻿using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using VehicleDashboard.Models;

namespace VehicleDashboard.Data.SeededData
{
    public class VehicleDbSeeder
    {
        private readonly VehicleDbContext dbContext;
        private readonly IHostingEnvironment hosting;

        public VehicleDbSeeder(VehicleDbContext dbContext, IHostingEnvironment hosting)
        {
            this.dbContext = dbContext;
            this.hosting = hosting;
        }

        public void Seed()
        {
            SeedVehicles();
            SeedEngines();
            SeedTransmissions();
            SeedBrakes();
            SeedWheels();
        }

        public void SeedVehicles()
        {
            dbContext.Database.EnsureCreated();
            if (!dbContext.Vehicles.Any())
            {
                var filePath = Path.Combine(hosting.ContentRootPath, "Data/SeedData/Vehicles.json");
                var json = File.ReadAllText(filePath);
                var vehicles = JsonConvert.DeserializeObject<IEnumerable<Vehicle>>(json);
                dbContext.Vehicles.AddRange(vehicles);
                dbContext.SaveChanges();
            }
        }

        public void SeedEngines()
        {
            dbContext.Database.EnsureCreated();
            if (!dbContext.Engines.Any())
            {
                var filePath = Path.Combine(hosting.ContentRootPath, "Data/SeedData/Engines.json");
                var json = File.ReadAllText(filePath);
                var engines = JsonConvert.DeserializeObject<IEnumerable<Engine>>(json);
                dbContext.Engines.AddRange(engines);
                dbContext.SaveChanges();
            }
        }

        public void SeedWheels()
        {
            dbContext.Database.EnsureCreated();
            if (!dbContext.Wheels.Any())
            {
                var filePath = Path.Combine(hosting.ContentRootPath, "Data/SeedData/Wheels.json");
                var json = File.ReadAllText(filePath);
                var wheels = JsonConvert.DeserializeObject<IEnumerable<Wheels>>(json);
                dbContext.Wheels.AddRange(wheels);
                dbContext.SaveChanges();
            }
        }

        public void SeedTransmissions()
        {
            dbContext.Database.EnsureCreated();
            if (!dbContext.Transmissions.Any())
            {
                var filePath = Path.Combine(hosting.ContentRootPath, "Data/SeedData/Transmissions.json");
                var json = File.ReadAllText(filePath);
                var transmissions = JsonConvert.DeserializeObject<IEnumerable<Transmission>>(json);
                dbContext.Transmissions.AddRange(transmissions);
                dbContext.SaveChanges();
            }
        }

        public void SeedBrakes()
        {
            dbContext.Database.EnsureCreated();
            if (!dbContext.Brakes.Any())
            {
                var filePath = Path.Combine(hosting.ContentRootPath, "Data/SeedData/Brakes.json");
                var json = File.ReadAllText(filePath);
                var brakes = JsonConvert.DeserializeObject<IEnumerable<Brakes>>(json);
                dbContext.Brakes.AddRange(brakes);
                dbContext.SaveChanges();
            }
        }
    }
}