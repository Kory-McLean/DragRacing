﻿using Microsoft.EntityFrameworkCore;
using VehicleDashboard.Models;

namespace VehicleDashboard.Data
{
    public class VehicleDbContext : DbContext
    {
        public VehicleDbContext(DbContextOptions<VehicleDbContext> options) : base(options) { }

        public DbSet<Vehicle> Vehicles { get; set; }
        public DbSet<Engine> Engines { get; set; }
        public DbSet<Transmission> Transmissions { get; set; }
        public DbSet<Wheels> Wheels { get; set; }
        public DbSet<Brakes> Brakes { get; set; }
    }
}
