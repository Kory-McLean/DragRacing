﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using VehicleDashboard.Data;
using VehicleDashboard.Models;
using VehicleDashboard.Services;
using VehicleDashboard.ViewModels;

namespace VehicleDashboard.Controllers
{
    public class DashboardController : Controller
    {
        private IComponentService componentService;

        public DashboardController(VehicleDbContext dbContext)
        {
            componentService = new ComponentService(dbContext);
        }

        [HttpPost]
        public IActionResult Dashboard(IFormCollection form)
        {
            DashboardViewModel viewModel = new DashboardViewModel()
            {
                PlayerOneVehicle = SetUpPlayerVehicle(form, "One"),
                PlayerTwoVehicle = SetUpPlayerVehicle(form, "Two")
            };
            return View(viewModel);
        }

        private Vehicle SetUpPlayerVehicle(IFormCollection form, string player)
        {
            int playerVehicleIndexSelected = Convert.ToInt32(form["player" + player + "VehicleIndex"].ToString()) + 1;
            int playerEngineIndexSelected = Convert.ToInt32(form["player" + player + "EngineIndex"].ToString()) + 1;
            int playerTransmissionIndexSelected = Convert.ToInt32(form["player" + player + "TransmissionIndex"].ToString()) + 1;
            int playerWheelsIndexSelected = Convert.ToInt32(form["player" + player + "WheelsIndex"].ToString()) + 1;
            int playerBrakesIndexSelected = Convert.ToInt32(form["player" + player + "BrakesIndex"].ToString()) + 1;

            Vehicle playerVehicleFromDb = componentService.GetVehicleById(playerVehicleIndexSelected);

            return new Vehicle()
            {
                ModelName = playerVehicleFromDb.ModelName,
                Mass = playerVehicleFromDb.Mass,
                Engine = componentService.GetEngineById(playerEngineIndexSelected),
                BrakePads = componentService.GetBrakesById(playerBrakesIndexSelected),
                Transmission = componentService.GetTransmissionById(playerTransmissionIndexSelected),
                Wheels = componentService.GetWheelsById(playerWheelsIndexSelected)
            };
        }
    }
}