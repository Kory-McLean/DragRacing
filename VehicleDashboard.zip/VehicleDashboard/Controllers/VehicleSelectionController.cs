﻿using Microsoft.AspNetCore.Mvc;
using VehicleDashboard.Data;
using VehicleDashboard.Services;
using VehicleDashboard.ViewModels;

namespace VehicleDashboard.Controllers
{
    public class VehicleSelectionController : Controller
    {
        private IComponentService componentService;

        public VehicleSelectionController(VehicleDbContext dbContext)
        {
            componentService = new ComponentService(dbContext);
        }

        public IActionResult TwoPlayerVehicleSelection()
        {
            VehicleSelectionViewModel viewModel = new VehicleSelectionViewModel()
            {
                Vehicles = componentService.GetVehicles(),
                Engines = componentService.GetEngines(),
                Transmissions = componentService.GetTransmissions(),
                Brakes = componentService.GetBrakes(),
                Wheels = componentService.GetWheels()
            };
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult RedirectToTwoPlayerSelection()
        {
            return RedirectToAction("TwoPlayerVehicleSelection");
        }
    }
}
