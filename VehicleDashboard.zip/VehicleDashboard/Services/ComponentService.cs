﻿using System.Collections.Generic;
using VehicleDashboard.Data;
using VehicleDashboard.Data.Repositories;
using VehicleDashboard.Models;

namespace VehicleDashboard.Services
{
    public class ComponentService : IComponentService
    {
        private IComponentRepository componentRepository;
        public ComponentService(VehicleDbContext dbContext)
        {
            componentRepository = new ComponentRepository(dbContext);
        }

        public ComponentService(IComponentRepository componentRepository)
        {
            this.componentRepository = componentRepository;
        }
        public List<Brakes> GetBrakes()
        {
            return componentRepository.GetBrakes();
        }

        public Brakes GetBrakesById(int id)
        {
            return componentRepository.GetBrakesById(id);
        }

        public Engine GetEngineById(int id)
        {
            return componentRepository.GetEngineById(id);
        }

        public List<Engine> GetEngines()
        {
            return componentRepository.GetEngines();
        }

        public Transmission GetTransmissionById(int id)
        {
            return componentRepository.GetTransmissionById(id);
        }

        public List<Transmission> GetTransmissions()
        {
            return componentRepository.GetTransmissions();
        }

        public Vehicle GetVehicleById(int id)
        {
            return componentRepository.GetVehicleById(id);
        }

        public List<Vehicle> GetVehicles()
        {
            return componentRepository.GetVehicles();
        }

        public List<Wheels> GetWheels()
        {
            return componentRepository.GetWheels();
        }

        public Wheels GetWheelsById(int id)
        {
            return componentRepository.GetWheelsById(id);
        }
    }
}
