﻿using System.Collections.Generic;
using VehicleDashboard.Models;

namespace VehicleDashboard.ViewModels
{
    public class VehicleSelectionViewModel
    {
        public List<Vehicle> Vehicles { get; set; }
        public List<Engine> Engines { get; set; }
        public List<Transmission> Transmissions { get; set; }
        public List<Brakes> Brakes { get; set; }
        public List<Wheels> Wheels { get; set; }
    }
}
