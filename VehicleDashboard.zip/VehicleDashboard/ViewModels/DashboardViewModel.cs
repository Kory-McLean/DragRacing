﻿using VehicleDashboard.Models;

namespace VehicleDashboard.ViewModels
{
    public class DashboardViewModel
    {
        public Vehicle PlayerOneVehicle { get; set; }
        public Vehicle PlayerTwoVehicle { get; set; }
    }
}
