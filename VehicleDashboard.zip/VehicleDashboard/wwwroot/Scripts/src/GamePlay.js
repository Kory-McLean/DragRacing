﻿var playerOneCar = document.getElementById("blueCar");
var playerTwoCar = document.getElementById("whiteCar");
var policeCarOne = document.getElementById("policeCarOne");
var policeCarTwo = document.getElementById("policeCarTwo");

var playerOneWinnerSign = document.getElementById("playerOneWinnerSign");
var playerOneBustedSign = document.getElementById("playerOneBustedSign");
var playerTwoWinnerSign = document.getElementById("playerTwoWinnerSign");
var playerTwoBustedSign = document.getElementById("playerTwoBustedSign");

var instructionsPrompt = document.getElementById("instructionsPrompt");
var instructionsText = document.getElementById("instructionsDiv");

var restartButton = document.getElementById("restartButton");

var playerOneCanWin = true;
var playerTwoCanWin = true;
var gamePlayVerifier = new GamePlayVerifier();
var windowSize = window.innerWidth;

setUpInstructions();
restartButton.addEventListener("click", function () {
    location.reload();
});
(function loop() {
    window.requestAnimationFrame(loop);

    if (playerOneCar.getBoundingClientRect().x > windowSize) {
        playerOneCar.style.left = "-60px";
        playerOneCanMove = false;

    }
    if (playerTwoCar.getBoundingClientRect().x > windowSize) {
        playerTwoCar.style.left = "-60px";
        playerTwoCanMove = false;
    }

    if (gamePlayVerifier.hasFinishedRace(playerOneCar.getBoundingClientRect().x + 60, windowSize - 210)) {
        if (gamePlayVerifier.isSpeedLegal(playerOneSpeed) && playerOneCanWin) {
            playerOneWinnerSign.style.visibility = "visible";
            restartButton.style.visibility = "visible";
            hideStripLights();
            playerOneCanDrive = false;
            playerTwoCanWin = false;
        }
        else if (!gamePlayVerifier.isSpeedLegal(playerOneSpeed)) {
            playerOneCanWin = false;
            policeCarOne.style.bottom = "160px";
            setTimeout(function () {
                playerOneCanDrive = false;
                playerOneCanMove = false;
                playerOneBustedSign.style.visibility = "visible";
            }, 1000);
        }
        else {
            playerOneCanDrive = false;
        }
    }
    if (gamePlayVerifier.hasFinishedRace(playerTwoCar.getBoundingClientRect().x + 60, windowSize - 210)) {
        if (gamePlayVerifier.isSpeedLegal(playerTwoSpeed) && playerTwoCanWin) {

            playerTwoWinnerSign.style.visibility = "visible";
            restartButton.style.visibility = "visible";
            hideStripLights();
            playerTwoCanDrive = false;
            playerOneCanWin = false;
        }
        else if (!gamePlayVerifier.isSpeedLegal(playerTwoSpeed)) {
            playerTwoCanWin = false;
            policeCarTwo.style.bottom = "30px";
            setTimeout(function () {
                playerTwoCanDrive = false;
                playerTwoCanMove = false;
                playerTwoBustedSign.style.visibility = "visible";
            }, 1000);
        }
        else {
            playerTwoCanDrive = false;
        }
    }
    if (!playerOneCanWin && !playerTwoCanWin) {
        hideStripLights();
        restartButton.style.visibility = "visible";
    }
})();

function hideStripLights() {
    document.getElementById("StripLights").style.visibility = "hidden";
    var circles = document.getElementsByClassName("circle");
    for (var i = 0; i < circles.length; i++) {
        circles[i].style.visibility = "hidden";
    }
}

function setUpInstructions() {
    instructionsPrompt.addEventListener("mouseenter", function () {
        instructionsText.style.display = "block";
    });

    instructionsPrompt.addEventListener("mouseleave", function () {
        instructionsText.style.display = "none";
    });
}