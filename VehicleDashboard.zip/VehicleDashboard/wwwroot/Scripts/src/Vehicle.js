﻿function Vehicle(config) {
    this.IdleRPM = config.IdleRPM;
    this.MaxRPM = config.MaxRPM;
    this.RedLineRPM = config.RedLineRPM;
    this.MinTorque = config.MinTorque;
    this.MaxTorque = config.MaxTorque;
    this.Gears = config.Gears;
    this.TransmitionRatio = config.TransmitionRatio;
    this.TransmitionLoss = config.TransmitionLoss;
    this.WheelDiameter = config.WheelDiameter;
    this.Mass = config.Mass;
    this.MaxBrakeTorque = config.MaxBrakeTorque;
};

Vehicle.prototype.torqueByRpm = function (rpm) {
    return (this.MinTorque + (rpm / this.MaxRPM) * (this.MaxTorque - this.MinTorque));
};