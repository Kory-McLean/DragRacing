﻿var playerTwoVehicleIndex;
var playerTwoEngineIndex;
var playerTwoTransmissionIndex;
var playerTwoWheelsIndex;
var playerTwoBrakesIndex;
var sum = 5;

UpdatePlayerTwoUIBasedOnValidation(sum);

var playerTwoLockInButton = document.getElementById('playerTwoLockInButton');

playerTwoLockInButton.addEventListener('click', function () {
    if (playerTwoLockedIn) {
        UnLockPlayerTwo();
    }
    else {
        LockPlayerTwo();
    }
    if (canAdvance) {
        document.querySelectorAll(".inputDisplay").forEach(o => o.style.visibility = "visible");
    }
    else {
        document.querySelectorAll(".inputDisplay").forEach(o => o.style.visibility = "hidden");
    }
});

var carouselControls = document.querySelectorAll('.carousel-control');
carouselControls.forEach(c => c.addEventListener('click', function () {
    //Here we will calculate the total cost of the currently selected vehicle
    setTimeout(function () {
        sum = 5;
        playerTwoVehicleIndex = $('#PlayerTwoVehicleModelCarousel .active').index('#PlayerTwoVehicleModelCarousel .item');
        playerTwoTransmissionIndex = $('#PlayerTwoTransmissionCarousel .active').index('#PlayerTwoTransmissionCarousel .item');
        playerTwoEngineIndex = $('#PlayerTwoEngineCarousel .active').index('#PlayerTwoEngineCarousel .item');
        playerTwoWheelsIndex = $('#PlayerTwoWheelsCarousel .active').index('#PlayerTwoWheelsCarousel .item');
        playerTwoBrakesIndex = $('#PlayerTwoBrakesCarousel .active').index('#PlayerTwoBrakesCarousel .item');
        sum += (playerTwoVehicleIndex + playerTwoTransmissionIndex + playerTwoEngineIndex + playerTwoWheelsIndex + playerTwoBrakesIndex);
        document.getElementById("playerTwoTotalCost").innerHTML = sum;
        UpdatePlayerTwoUIBasedOnValidation(sum);
    }, 700);
}));

function IsCostValid(cost) {
    return cost <= 10;
}

function HidePlayerTwoLockInButton() {
    document.getElementById('playerTwoLockInButton').style.display = "none";
    document.getElementById('playerTwoValidationMsg').style.display = "";
    document.getElementById('playerTwoTotalCost').style.color = "red";
}

function ShowPlayerTwoLockInButton() {
    document.getElementById('playerTwoLockInButton').style.display = "";
    document.getElementById('playerTwoValidationMsg').style.display = "none";
    document.getElementById('playerTwoTotalCost').style.color = "black";
}

function DisablePlayerTwoCarouselControls() {
    var playerTwoSelectionPanel = document.querySelector('#playerTwoSelection');
    var carouselControls = playerTwoSelectionPanel.querySelectorAll('.carousel-control');
    carouselControls.forEach(c => c.style.visibility = "hidden");
}

function EnablePlayerTwoCarouselControls() {
    var playerTwoSelectionPanel = document.querySelector('#playerTwoSelection');
    var carouselControls = playerTwoSelectionPanel.querySelectorAll('.carousel-control');
    carouselControls.forEach(c => c.style.visibility = "visible");
}

function LockPlayerTwo() {
    playerTwoLockedIn = true;
    playerTwoLockInButton.innerHTML = "UNREADY";
    playerTwoLockInButton.classList.replace("btn-primary", "btn-danger");
    DisablePlayerTwoCarouselControls();
    canAdvance = playerOneLockedIn && playerTwoLockedIn;
}

function UnLockPlayerTwo() {
    playerTwoLockedIn = false;
    playerTwoLockInButton.innerHTML = "READY UP";
    playerTwoLockInButton.classList.replace("btn-danger", "btn-primary");
    EnablePlayerTwoCarouselControls();
    canAdvance = playerOneLockedIn && playerTwoLockedIn;
}

function UpdatePlayerTwoUIBasedOnValidation(cost) {
    if (IsCostValid(cost)) {
        ShowPlayerTwoLockInButton();
    }
    else {
        HidePlayerTwoLockInButton();
    }
}
