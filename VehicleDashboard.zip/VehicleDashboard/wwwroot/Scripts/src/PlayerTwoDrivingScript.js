﻿//Document Object Model Loading
var PlayerTwoDrivingScript = PlayerTwoDrivingScript || (function () {
    var vehicle = {};

    return {
        init: function (Args) {
            vehicle = Args;
        },
        drive: function () {
            document.addEventListener("DOMContentLoaded", function () {

                let rpmMeter2 = new Meter(document.querySelector(".playerTwoRPM"), {
                    value: 6.3, // check
                    meterMinValue: 30,
                    meterMaxValue: 8000,
                    intervalValue: 1000,
                    meterValueUnit: "<div>RPM</div><span>x1000</span>",
                    angleMin: 00, // test
                    angleMax: 330, //test
                    labelUnit: "RPM",
                    labelFormat: function (value) { return Math.round(value / 1000); },
                    needleFormat: function (value) { return Math.round(value / 100) * 100; },
                    meterRedValue: 6500
                });

                //Set Up the Speed Meter
                let speedMeter2 = new Meter(document.querySelector(".playerTwoSpeed"), {
                    value: 203, // check
                    meterMinValue: 0,
                    meterMaxValue: 220, // Can set this to the actual cars top speed
                    intervalValue: 20,
                    meterValueUnit: "<span>Speed</span><div>Km/h</div>",
                    angleMin: 30,
                    angleMax: 330,
                    labelUnit: "Km/h",
                    labelFormat: function (value) { return Math.round(value); },
                    needleFormat: function (value) { return Math.round(value); }
                });
                let gearMeter2 = document.querySelector('.playerTwoGear div');



                //User Inputs
                document.addEventListener('keydown', function (e) {
                    if (playerTwoCanDrive) {

                        if (e.keyCode == '38') { 			// up arrow
                            playerTwoIsAccelerating = true;
                        }
                        else if (e.keyCode == '40') { // down arrow
                            playerTwoIsBraking = true;
                        }
                        else if (e.keyCode == '37') { // left arrow
                        }
                        else if (e.keyCode == '39') { // right arrow
                        }
                    }

                });

                document.addEventListener('keyup', function (e) {
                    if (e.keyCode == '38') {			// up arrow
                        playerTwoIsAccelerating = false;
                    }
                    else if (e.keyCode == '40') { // down arrow
                        playerTwoIsBraking = false;
                    }
                    else if (e.keyCode == '37') { // left arrow
                        gearDown();
                    }
                    else if (e.keyCode == '39') { // right arrow
                        gearUp();
                    }

                });

                function gearUp() {
                    if (gear < gears.length - 1) {
                        gear++;
                        gearMeter2.innerHTML = gear;
                    }
                }

                function gearDown() {
                    if (gear > 1) {
                        gear--;
                        gearMeter2.innerHTML = gear;
                    }
                }

                //Vehicle Config  => Values should be passed in via the model in some way
                let
                    mass = vehicle.Mass,
                    cx = 0.28, //idk what this is exactly
                    gears = vehicle.Gears,
                    transmitionRatio = vehicle.TransmitionRatio,
                    transmitionLoss = vehicle.TransmitionLoss,
                    wheelDiameter = vehicle.WheelDiameter,
                    brakeTorqueMax = vehicle.MaxBrakeTorque,

                    gear = 1,
                    speed = 10,	// in km/h
                    overallRatio,
                    wheelRpm,
                    wheelTorque,
                    brakeTorque,
                    resistance,
                    acceleration;

                //MOTOR CONFIG => Values should be passed in via the model in some way

                let
                    rpmIdle = vehicle.IdleRPM,
                    rpmMax = vehicle.MaxRPM,
                    rpmRedzone = vehicle.RedLineRPM,
                    torqueMin = vehicle.MinTorque, // in m.kg
                    torqueMax = vehicle.MaxTorque, // in m.kg

                    torque,
                    rpm = 0,
                    playerTwoIsAccelerating = false,
                    playerTwoIsBraking = false;

                //Helper functions

                //Replace with calls to vehicle.torqueByRpm
                let torqueByRpm = function (rpm) {
                    let torque = torqueMin + (rpm / rpmMax) * (torqueMax - torqueMin);
                    return torque;
                };

                function convertKmhIntoMs(speed) {	// Km/h to m/s
                    return speed / 3.6;
                }

                let lastTime = new Date().getTime(),
                    nowTime,
                    delta;

                // MAIN LOOP
                var whiteCar = document.getElementById("whiteCar");
                var rect;
                (function loop() {
                    window.requestAnimationFrame(loop);

                    //Delta time
                    nowTime = new Date().getTime();
                    delta = (nowTime - lastTime) / 1000; // in seconds
                    lastTime = nowTime;

                    let oldSpeed = speed,
                        oldRpm = rpm;

                    //Torque

                    if (playerTwoIsAccelerating && rpm < rpmMax) {	// Gas!
                        torque = torqueByRpm(rpm);
                        if (playerTwoCanMove) {
                            var rect = whiteCar.getBoundingClientRect();
                            var newPosition = (rect.x + (speed * movementMultiplier/  80));
                            whiteCar.style.left = newPosition + "px";
                        }

                    } else {
                        torque = -(rpm * rpm / 1000000);
                        if (playerTwoCanMove) {
                            var rect = whiteCar.getBoundingClientRect();
                            var newPosition = (rect.x + (speed * movementMultiplier / 80));
                            whiteCar.style.left = newPosition + "px";
                        }
                    }

                    if (playerTwoIsBraking) {	// Ooops...
                        brakeTorque = brakeTorqueMax;
                    } else {
                        brakeTorque = 0;
                    }


                    overallRatio = transmitionRatio * gears[gear];
                    wheelTorque = torque / overallRatio - brakeTorque;

                    acceleration = 20 * wheelTorque / (wheelDiameter * mass / 2);
                    resistance = 0.5 * 1.2 * cx * convertKmhIntoMs(speed) ^ 2;

                    //Speed

                    speed += (acceleration - resistance) * delta;


                    if (speed < 0) { speed = 0; }

                    wheelRpm = speed / (60 * (Math.PI * wheelDiameter / 1000));
                    rpm = speed / (60 * transmitionRatio * gears[gear] * (Math.PI * wheelDiameter / 1000));

                    //Idle
                    if (rpm < rpmIdle) {
                        rpm = oldRpm;
                        speed = oldSpeed;
                    }

                    //  Gear shifter
                    if (rpm > rpmRedzone) {
                        gearMeter2.classList.add('redzone');

                    } else {
                        gearMeter2.classList.remove('redzone');
                    }

                    // Update GUI

                    speedMeter2.setMeterValue(speed);
                    playerTwoSpeed = speed;
                    rpmMeter2.setMeterValue(rpm);

                })();
            });
        }
    };
}());