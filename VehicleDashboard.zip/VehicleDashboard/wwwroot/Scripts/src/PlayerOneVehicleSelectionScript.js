﻿var playerOneVehicleIndex;
var playerOneEngineIndex;
var playerOneTransmissionIndex;
var playerOneWheelsIndex;
var playerOneBrakesIndex;
var sum = 5;

UpdatePlayerOneUIBasedOnValidation(sum);

var playerOneLockInButton = document.getElementById('playerOneLockInButton');

playerOneLockInButton.addEventListener('click', function () {
    if (playerOneLockedIn) {
        UnLockPlayerOne();
    }
    else {
        LockPlayerOne();
    }
    if (canAdvance) {
        document.querySelectorAll(".inputDisplay").forEach(o => o.style.visibility = "visible");
    }
    else {
        document.querySelectorAll(".inputDisplay").forEach(o => o.style.visibility = "hidden");
    }
});

var carouselControls = document.querySelectorAll('.carousel-control');
carouselControls.forEach(c => c.addEventListener('click', function () {
    //Here we will calculate the total cost of the currently selected vehicle
    setTimeout(function () {
        sum = 5;
        playerOneVehicleIndex = $('#PlayerOneVehicleModelCarousel .active').index('#PlayerOneVehicleModelCarousel .item');
        playerOneTransmissionIndex = $('#PlayerOneTransmissionCarousel .active').index('#PlayerOneTransmissionCarousel .item');
        playerOneEngineIndex = $('#PlayerOneEngineCarousel .active').index('#PlayerOneEngineCarousel .item');
        playerOneWheelsIndex = $('#PlayerOneWheelsCarousel .active').index('#PlayerOneWheelsCarousel .item');
        playerOneBrakesIndex = $('#PlayerOneBrakesCarousel .active').index('#PlayerOneBrakesCarousel .item');
        sum += (playerOneVehicleIndex + playerOneTransmissionIndex + playerOneEngineIndex + playerOneWheelsIndex + playerOneBrakesIndex);
        document.getElementById("playerOneTotalCost").innerHTML = sum;
        UpdatePlayerOneUIBasedOnValidation(sum);
    }, 700);
}));

function IsCostValid(cost) {
    return cost <= 10;
}

function HidePlayerOneLockInButton() {
    document.getElementById('playerOneLockInButton').style.display = "none";
    document.getElementById('playerOneValidationMsg').style.display = "";
    document.getElementById('playerOneTotalCost').style.color = "red";
}

function ShowPlayerOneLockInButton() {
    document.getElementById('playerOneLockInButton').style.display = "";
    document.getElementById('playerOneValidationMsg').style.display = "none";
    document.getElementById('playerOneTotalCost').style.color = "black";
}

function DisablePlayerOneCarouselControls() {
    var playerOneSelectionPanel = document.querySelector('#playerOneSelection');
    var carouselControls = playerOneSelectionPanel.querySelectorAll('.carousel-control');
    carouselControls.forEach(c => c.style.visibility = "hidden");
}

function EnablePlayerOneCarouselControls() {
    var playerOneSelectionPanel = document.querySelector('#playerOneSelection');
    var carouselControls = playerOneSelectionPanel.querySelectorAll('.carousel-control');
    carouselControls.forEach(c => c.style.visibility = "visible");
}

function LockPlayerOne() {
    playerOneLockedIn = true;
    playerOneLockInButton.innerHTML = "UNREADY";
    playerOneLockInButton.classList.replace("btn-primary", "btn-danger");
    DisablePlayerOneCarouselControls();
    canAdvance = playerOneLockedIn && playerTwoLockedIn;
}

function UnLockPlayerOne() {
    playerOneLockedIn = false;
    playerOneLockInButton.innerHTML = "READY UP";
    playerOneLockInButton.classList.replace("btn-danger", "btn-primary");
    EnablePlayerOneCarouselControls();
    canAdvance = playerOneLockedIn && playerTwoLockedIn;
}

function UpdatePlayerOneUIBasedOnValidation(cost) {
    if (IsCostValid(cost)) {
        ShowPlayerOneLockInButton();
    }
    else {
        HidePlayerOneLockInButton();
    }
}
