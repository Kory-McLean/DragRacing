﻿let Meter = function Meter($elm, config) {

    let $meterNeedle, $meterValue

    let numberOfIntervals = (config.meterMaxValue - config.meterMinValue) / config.intervalValue,
        intervalAngle = (config.angleMax - config.angleMin) / numberOfIntervals;

    //Rename these
    let margin = 10;
    let angle = 0;
    var currentValue;

    let meterValueToAngle = function (meterValue) {
        let angle = ((meterValue / (config.meterMaxValue - config.meterMinValue)) * (config.angleMax - config.angleMin) + config.angleMin);
        return angle;
    }

    this.setMeterValue = function (value) {
        $meterNeedle.style.transform = "translate3d(-50%, 0, 0) rotate(" + Math.round(meterValueToAngle(value)) + "deg)"
        $meterValue.innerHTML = config.needleFormat(value); // Idk what this does
        currentValue = value;
    }

    this.getMeterValue = function () {
        return currentValue;
    }

    let switchLabel = function (e) {
        e.target.closest(".meter").classList.toggle('meter--big-label');
    };

    let makeElement = function (parent, className, innerHtml, style) {

        let newDiv = document.createElement('div');
        newDiv.className = className;

        if (innerHtml) {
            newDiv.innerHTML = innerHtml;
        }

        if (style) {
            for (var property in style) {
                newDiv.style[property] = style[property];
            }
        }

        parent.appendChild(newDiv);

        return newDiv;
    };

    //Label the meter
    makeElement($elm, "label label-unit", config.meterValueUnit);

    for (let i = 0; i < numberOfIntervals + 1; i++) {
        let value = config.meterMinValue + i * config.intervalValue;
        angle = config.angleMin + i * intervalAngle;

        let meterRedZone = "";
        if (value > config.meterRedValue) {
            meterRedZone = " redzone";
        }

        makeElement($elm, "grad grad--" + i + meterRedZone, config.labelFormat(value), {
            left: (50 - (50 - margin) * Math.sin(angle * (Math.PI / 180))) + "%",
            top: (50 + (50 - margin) * Math.cos(angle * (Math.PI / 180))) + "%"
        });

        // Tick
        makeElement($elm, "grad-tick grad-tick--" + i + meterRedZone, "", {
            left: (50 - 50 * Math.sin(angle * (Math.PI / 180))) + "%",
            top: (50 + 50 * Math.cos(angle * (Math.PI / 180))) + "%",
            transform: "translate3d(-50%, 0, 0) rotate(" + (angle + 180) + "deg)"
        });

        // Half ticks
        angle += intervalAngle / 2;

        if (angle < config.angleMax) {
            makeElement($elm, "grad-tick grad-tick--half grad-tick--" + i + meterRedZone, "", {
                left: (50 - 50 * Math.sin(angle * (Math.PI / 180))) + "%",
                top: (50 + 50 * Math.cos(angle * (Math.PI / 180))) + "%",
                transform: "translate3d(-50%, 0, 0) rotate(" + (angle + 180) + "deg)"
            });
        }

        // Quarter ticks
        angle += intervalAngle / 4;

        if (angle < config.angleMax) {
            makeElement($elm, "grad-tick grad-tick--quarter grad-tick--" + i + meterRedZone, "", {
                left: (50 - 50 * Math.sin(angle * (Math.PI / 180))) + "%",
                top: (50 + 50 * Math.cos(angle * (Math.PI / 180))) + "%",
                transform: "translate3d(-50%, 0, 0) rotate(" + (angle + 180) + "deg)"
            });
        }

        angle -= intervalAngle / 2;

        if (angle < config.angleMax) {
            makeElement($elm, "grad-tick grad-tick--quarter grad-tick--" + i + meterRedZone, "", {
                left: (50 - 50 * Math.sin(angle * (Math.PI / 180))) + "%",
                top: (50 + 50 * Math.cos(angle * (Math.PI / 180))) + "%",
                transform: "translate3d(-50%, 0, 0) rotate(" + (angle + 180) + "deg)"
            });
        }
    }

    // NEEDLE
    angle = meterValueToAngle(config.value);

    $meterNeedle = makeElement($elm, "needle", "", {
        transform: "translate3d(-50%, 0, 0) rotate(" + angle + "deg)"
    });

    let $axle = makeElement($elm, "needle-axle").addEventListener("click", switchLabel);
    makeElement($elm, "label label-value", "<div>" + config.labelFormat(config.value) + "</div>" + "<span>" + config.labelUnit + "</span>").addEventListener("click", switchLabel);

    $meterValue = $elm.querySelector(".label-value div");
};