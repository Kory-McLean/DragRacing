﻿//Player One Controls
var playerOneUIIsInversed = false;
var playerOneInverseButton = document.getElementById("playerOneInverseColorButton");

var playerOneUI = document.getElementById("playerOneMeters");
var playerOneMeters = playerOneUI.querySelectorAll(".meter");
var playerOneLabels = playerOneUI.getElementsByClassName("label");
var playerOneLabelValue = playerOneUI.getElementsByClassName("label-value");
var playerOneGrad = playerOneUI.getElementsByClassName("grad");
var playerOneGradTicks = playerOneUI.getElementsByClassName("grad-tick");
var playerOneMeterGear = playerOneUI.getElementsByClassName("meter--gear");
var playerOneMeterGearValue = playerOneMeterGear[0].getElementsByTagName("div");

var playerOneRedZoneLabel = playerOneUI.getElementsByClassName("grad redzone");
var playerOneRedZoneTicks = playerOneUI.getElementsByClassName("grad-tick redzone");

playerOneInverseButton.addEventListener("click", function () {

    if (playerOneUIIsInversed) {
        playerOneMeters.forEach(o => o.style.backgroundColor = "white");
        assignPlayerUIElementColor(playerOneLabels, "#555");
        assignPlayerUIElementColor(playerOneLabelValue, "white");
        assignPlayerUIElementColor(playerOneGrad, "#555");
        assignPlayerUIElementBackGround(playerOneGradTicks, "#555");
        playerOneMeterGearValue[0].classList.remove('inverse');

    }
    else {
        playerOneMeters.forEach(o => o.style.backgroundColor = "#555");
        assignPlayerUIElementColor(playerOneLabels, "yellow");
        assignPlayerUIElementColor(playerOneLabelValue, "white");
        assignPlayerUIElementColor(playerOneGrad, "cyan");
        assignPlayerUIElementBackGround(playerOneGradTicks, "white");
        playerOneMeterGearValue[0].classList.add('inverse');

    }
    assignPlayerUIElementColor(playerOneRedZoneLabel, "#e30");
    assignPlayerUIElementBackGround(playerOneRedZoneTicks, "#e30");
    playerOneUIIsInversed = !playerOneUIIsInversed;
});

//Player Two Controls
var playerTwoUIIsInversed = false;
var playerTwoInverseButton = document.getElementById("playerTwoInverseColorButton");

var playerTwoUI = document.getElementById("playerTwoMeters");
var playerTwoMeters = playerTwoUI.querySelectorAll(".meter");
var playerTwoLabels = playerTwoUI.getElementsByClassName("label");
var playerTwoLabelValue = playerTwoUI.getElementsByClassName("label-value");
var playerTwoGrad = playerTwoUI.getElementsByClassName("grad");
var playerTwoGradTicks = playerTwoUI.getElementsByClassName("grad-tick");
var playerTwoMeterGear = playerTwoUI.getElementsByClassName("meter--gear");
var playerTwoMeterGearValue = playerTwoMeterGear[0].getElementsByTagName("div");

var playerTwoRedZoneLabel = playerTwoUI.getElementsByClassName("grad redzone");
var playerTwoRedZoneTicks = playerTwoUI.getElementsByClassName("grad-tick redzone");

playerTwoInverseButton.addEventListener("click", function () {

    if (playerTwoUIIsInversed) {
        playerTwoMeters.forEach(o => o.style.backgroundColor = "white");
        assignPlayerUIElementColor(playerTwoLabels, "#555");
        assignPlayerUIElementColor(playerTwoLabelValue, "white");
        assignPlayerUIElementColor(playerTwoGrad, "#555");
        assignPlayerUIElementBackGround(playerTwoGradTicks, "#555");
        playerTwoMeterGearValue[0].classList.remove('inverse');

    }
    else {
        playerTwoMeters.forEach(o => o.style.backgroundColor = "#555");
        assignPlayerUIElementColor(playerTwoLabels, "yellow");
        assignPlayerUIElementColor(playerTwoLabelValue, "white");
        assignPlayerUIElementColor(playerTwoGrad, "cyan");
        assignPlayerUIElementBackGround(playerTwoGradTicks, "white");
        playerTwoMeterGearValue[0].classList.add('inverse');
    }
    assignPlayerUIElementColor(playerTwoRedZoneLabel, "#e30");
    assignPlayerUIElementBackGround(playerTwoRedZoneTicks, "#e30");
    playerTwoUIIsInversed = !playerTwoUIIsInversed;
});

function assignPlayerUIElementBackGround(elements, styleValue) {
    for (var i = 0; i < elements.length; i++) {
        elements[i].style.backgroundColor = styleValue;
    }
}

function assignPlayerUIElementColor(elements, styleValue) {
    for (var i = 0; i < elements.length; i++) {
        elements[i].style.color = styleValue;
    }
}