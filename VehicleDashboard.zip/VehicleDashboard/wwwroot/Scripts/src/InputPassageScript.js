﻿var confirmInputButton = document.getElementById("confirmInputButton");
var playerTwoVehicleIndex;
var playerTwoEngineIndex;
var playerTwoTransmissionIndex;
var playerTwoWheelsIndex;
var playerTwoBrakesIndex;

var playerOneVehicleIndex;
var playerOneEngineIndex;
var playerOneTransmissionIndex;
var playerOneWheelsIndex;
var playerOneBrakesIndex;

var playerTwoVehicleIndexElement = document.getElementById('playerTwoVehicleIndex');
var playerTwoEngineIndexElement = document.getElementById('playerTwoEngineIndex');
var playerTwoTransmissionIndexElement = document.getElementById('playerTwoTransmissionIndex');
var playerTwoWheelsIndexElement = document.getElementById('playerTwoWheelsIndex');
var playerTwoBrakesIndexElement = document.getElementById('playerTwoBrakesIndex');

var playerOneVehicleIndexElement = document.getElementById('playerOneVehicleIndex');
var playerOneEngineIndexElement = document.getElementById('playerOneEngineIndex');
var playerOneTransmissionIndexElement = document.getElementById('playerOneTransmissionIndex');
var playerOneWheelsIndexElement = document.getElementById('playerOneWheelsIndex');
var playerOneBrakesIndexElement = document.getElementById('playerOneBrakesIndex');

confirmInputButton.addEventListener('click', function () {
    FillPlayerOneSelection();
    FillPlayerTwoSelection();
});


function FillPlayerTwoSelection() {
    playerTwoVehicleIndex = $('#PlayerTwoVehicleModelCarousel .active').index('#PlayerTwoVehicleModelCarousel .item');
    playerTwoTransmissionIndex = $('#PlayerTwoTransmissionCarousel .active').index('#PlayerTwoTransmissionCarousel .item');
    playerTwoEngineIndex = $('#PlayerTwoEngineCarousel .active').index('#PlayerTwoEngineCarousel .item');
    playerTwoWheelsIndex = $('#PlayerTwoWheelsCarousel .active').index('#PlayerTwoWheelsCarousel .item');
    playerTwoBrakesIndex = $('#PlayerTwoBrakesCarousel .active').index('#PlayerTwoBrakesCarousel .item');

    playerTwoVehicleIndexElement.setAttribute("value", playerTwoVehicleIndex);
    playerTwoTransmissionIndexElement.setAttribute("value", playerTwoTransmissionIndex);
    playerTwoEngineIndexElement.setAttribute("value", playerTwoEngineIndex);
    playerTwoWheelsIndexElement.setAttribute("value", playerTwoWheelsIndex);
    playerTwoBrakesIndexElement.setAttribute("value", playerTwoBrakesIndex);
}

function FillPlayerOneSelection() {
    playerOneVehicleIndex = $('#PlayerOneVehicleModelCarousel .active').index('#PlayerOneVehicleModelCarousel .item');
    playerOneTransmissionIndex = $('#PlayerOneTransmissionCarousel .active').index('#PlayerOneTransmissionCarousel .item');
    playerOneEngineIndex = $('#PlayerOneEngineCarousel .active').index('#PlayerOneEngineCarousel .item');
    playerOneWheelsIndex = $('#PlayerOneWheelsCarousel .active').index('#PlayerOneWheelsCarousel .item');
    playerOneBrakesIndex = $('#PlayerOneBrakesCarousel .active').index('#PlayerOneBrakesCarousel .item');

    playerOneVehicleIndexElement.setAttribute("value", playerOneVehicleIndex);
    playerOneTransmissionIndexElement.setAttribute("value", playerOneTransmissionIndex);
    playerOneEngineIndexElement.setAttribute("value", playerOneEngineIndex);
    playerOneWheelsIndexElement.setAttribute("value", playerOneWheelsIndex);
    playerOneBrakesIndexElement.setAttribute("value", playerOneBrakesIndex);
}

