﻿function GamePlayVerifier() {

}

GamePlayVerifier.prototype.isSpeedLegal = function (speed) {
    return speed <= 30;
};

GamePlayVerifier.prototype.hasFinishedRace = function (xPosition, boundry) {
    return xPosition >= boundry;
};

