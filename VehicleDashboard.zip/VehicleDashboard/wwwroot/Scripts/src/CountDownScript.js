﻿var stripLights = document.getElementById("StripLights");
var lights = document.querySelectorAll('.circle');
var raceStart = document.getElementById('RaceStartButton');
var movementMultipleSlider = document.getElementById("movementMultiplier");
lights.forEach(function (c) {
    c.style.visibility = 'hidden';
});
stripLights.style.visibility = 'hidden';
raceStart.addEventListener('click', function () {
    var i = 0;
    stripLights.style.visibility = 'visible';
    document.getElementById("title").style.display = "none";
    document.getElementById("sliderTitle").style.display = "none";
    movementMultipleSlider.style.display = "none";
    raceStart.style.display = "none";
    lights[4].style.visibility = "visible";
    var timer = setInterval(function () {
        lights[i].style.visibility = 'visible';
        if (i == 3) {
            clearInterval(timer);
            lights[4].style.visibility = "hidden";
            playerOneCanMove = true;
            playerTwoCanMove = true;
            playerOneCanDrive = true;
            playerTwoCanDrive = true;
        }
        i++;
        }, 1000);
});
movementMultipleSlider.addEventListener("input", function () {
    movementMultiplier = this.value / 40;
});
