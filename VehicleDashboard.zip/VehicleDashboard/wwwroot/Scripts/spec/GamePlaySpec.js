﻿describe("Game Play", function () {
    var testVerifier;
    beforeEach(function () {
        testVerifier = new GamePlayVerifier();
    });
    afterEach(function () {
        testVerifier = null;
    });
    describe("Test Speed Limit Restrictions", function () {
        it("Expect it to be defined", function () {
            expect(testVerifier.isSpeedLegal).toBeDefined();
        });
        it("Test its Return values", function () {
            expect(testVerifier.isSpeedLegal(10)).toBe(true);
            expect(testVerifier.isSpeedLegal(30)).toBe(true);
            expect(testVerifier.isSpeedLegal(31)).toBe(false);
            expect(testVerifier.isSpeedLegal(40)).toBe(false);
        })
    });

    describe("Test Race Finishing bool", function () {
        it("Expect it to be defined", function () {
            expect(testVerifier.hasFinishedRace).toBeDefined();
        });
        it("Test its Return values", function () {
            expect(testVerifier.hasFinishedRace(310, 210)).toBe(true);
            expect(testVerifier.hasFinishedRace(210, 210)).toBe(true);
            expect(testVerifier.hasFinishedRace(100, 210)).toBe(false);
            expect(testVerifier.hasFinishedRace(209, 210)).toBe(false);
        })
    });
});