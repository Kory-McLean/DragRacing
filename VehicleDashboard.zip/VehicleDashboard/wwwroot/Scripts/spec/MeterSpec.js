﻿describe("Meter Tests", function () {
    var testMeter;

    beforeEach(function () {
        testMeter = new Meter(document.querySelector(".playerOneRPM"), {
            value: 6.3, // check
            meterMinValue: 30,
            meterMaxValue: 8000,//8000,
            intervalValue: 1000,
            meterValueUnit: "<div>RPM</div><span>x1000</span>",
            angleMin: 00, // test
            angleMax: 330, //test
            labelUnit: "RPM",
            labelFormat: function (value) { return Math.round(value / 1000); },
            needleFormat: function (value) { return Math.round(value / 100) * 100; },
            meterRedValue: 6500
        });
    });

    afterEach(function () {
        testMeter = null;
    });

    describe("Testing Getting the Meter Value", function () {

        it("Make sure the method is defined", function () {
            expect(testMeter.getMeterValue).toBeDefined();
            expect(testMeter.setMeterValue).toBeDefined();
        });

        it("Test the return values", function () {
            testMeter.setMeterValue(48);
            expect(testMeter.getMeterValue()).toBe(48);
        });

        it("Test the mehtod extensively", function () {
            var i;
            for (i = 0; i < 220; i++) {
                testMeter.setMeterValue(i);
                expect(testMeter.getMeterValue()).toBe(i);
            }
        });

    });
});