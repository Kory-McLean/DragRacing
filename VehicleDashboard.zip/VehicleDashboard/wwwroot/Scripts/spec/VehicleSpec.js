﻿describe("Vehicle", function () {
    var config = {
        IdleRPM : 1200,
        MaxRPM : 8000,
        RedLineRPM : 6500,
        MinTorque : 20,
        MaxTorque : 45,
        Gears :[ 0, 0.4, 0.7, 1.0, 1.3, 1.5, 1.68 ],
        TransmitionRatio : 0.17,
        TransmitionLoss: 0.15,
        WheelDiameter: 0.5,
        Mass : 1000,
        MaxBrakeTorque : 300
    };

    beforeEach(function () {
        testVehicle = new Vehicle(config);
    });
    afterEach(function () {
        testVehicle = null;
    });

    describe("Instantiation", function () {
        it("We Expect all the desired properties to be defined", function () {
            expect(testVehicle.IdleRPM).toBeDefined();
            expect(testVehicle.MaxRPM).toBeDefined();
            expect(testVehicle.RedLineRPM).toBeDefined();
            expect(testVehicle.MinTorque).toBeDefined();
            expect(testVehicle.MaxRPM).toBeDefined();
            expect(testVehicle.Gears).toBeDefined();
            expect(testVehicle.TransmitionRatio).toBeDefined();
            expect(testVehicle.TransmitionLoss).toBeDefined();
            expect(testVehicle.WheelDiameter).toBeDefined();
            expect(testVehicle.Mass).toBeDefined();
            expect(testVehicle.MaxBrakeTorque).toBeDefined();
        });

        it("We expect that we will have 7 gears with the first gear to be 0", function () {
            expect(testVehicle.Gears.length).toBe(7);
            expect(testVehicle.Gears[0]).toBe(0);
        });
    });

    describe("Functions", function () {
        it("Test Vehicle.torqueByRpm", function () {
            expect(testVehicle.torqueByRpm).toBeDefined();
            expect(testVehicle.torqueByRpm(1000)).toBe(23.125);
        });
    });
});