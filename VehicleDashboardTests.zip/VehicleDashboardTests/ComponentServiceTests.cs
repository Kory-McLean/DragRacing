﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Shouldly;
using VehicleDashboard.Data.Repositories;
using VehicleDashboard.Models;
using VehicleDashboard.Services;

namespace VehicleDashboardTests
{
    [TestClass]
    public class ComponentServiceTests
    {
        private ComponentService _testee;
        private Mock<IComponentRepository> _componentRepositoryMock;

        [TestInitialize]
        public void Init()
        {
            _componentRepositoryMock = new Mock<IComponentRepository>();
            _testee = new ComponentService(_componentRepositoryMock.Object);
        }

        [TestMethod]
        public void GetBrakes_Should_ReturnAListOfBrakes()
        {
            _componentRepositoryMock.Setup(o => o.GetBrakes()).Returns(SetUpGetBrakesMock());
            List<Brakes> result = _testee.GetBrakes();
            result.Count.ShouldBe(3);

            int currentComponentCost = result[0].Cost;
            foreach(Brakes brake in result)
            {
                brake.Cost.ShouldBeGreaterThanOrEqualTo(currentComponentCost);
                currentComponentCost = brake.Cost;
            }
        }

        private List<Brakes> SetUpGetBrakesMock()
        {
            Brakes brakesOne = new Brakes();
            Brakes brakesTwo = new Brakes();
            Brakes brakesThree = new Brakes();
            return new List<Brakes>() { brakesOne, brakesTwo, brakesThree };
        }

        [TestMethod]
        public void GetVehicles_Should_ReturnAListOfBrakes()
        {
            _componentRepositoryMock.Setup(o => o.GetVehicles()).Returns(SetUpGetVehiclesMock());
            List<Vehicle> result = _testee.GetVehicles();
            result.Count.ShouldBe(3);

            int currentComponentCost = result[0].Cost;
            foreach (Vehicle vehicle in result)
            {
                vehicle.Cost.ShouldBeGreaterThanOrEqualTo(currentComponentCost);
                currentComponentCost = vehicle.Cost;
            }
        }

        private List<Vehicle> SetUpGetVehiclesMock()
        {
            Vehicle vehicleOne = new Vehicle();
            Vehicle vehicleTwo = new Vehicle();
            Vehicle vehicleThree = new Vehicle();
            return new List<Vehicle>() { vehicleOne, vehicleTwo, vehicleThree };
        }

        [TestMethod]
        public void GetWheels_Should_ReturnAListOfBrakes()
        {
            _componentRepositoryMock.Setup(o => o.GetWheels()).Returns(SetUpGetWheelsMock());
            List<Wheels> result = _testee.GetWheels();
            result.Count.ShouldBe(3);

            int currentComponentCost = result[0].Cost;
            foreach (Wheels wheels in result)
            {
                wheels.Cost.ShouldBeGreaterThanOrEqualTo(currentComponentCost);
                currentComponentCost = wheels.Cost;
            }
        }

        private List<Wheels> SetUpGetWheelsMock()
        {
            Wheels wheelsOne = new Wheels();
            Wheels wheelsTwo = new Wheels();
            Wheels wheelsThree = new Wheels();
            return new List<Wheels>() { wheelsOne, wheelsTwo, wheelsThree };
        }

        [TestMethod]
        public void GetEngines_Should_ReturnAListOfBrakes()
        {
            _componentRepositoryMock.Setup(o => o.GetEngines()).Returns(SetUpGetEnginesMock());
            List<Engine> result = _testee.GetEngines();
            result.Count.ShouldBe(3);

            int currentComponentCost = result[0].Cost;
            foreach (Engine engine in result)
            {
                engine.Cost.ShouldBeGreaterThanOrEqualTo(currentComponentCost);
                currentComponentCost = engine.Cost;
            }
        }

        private List<Engine> SetUpGetEnginesMock()
        {
            Engine engineOne = new Engine();
            Engine engineTwo = new Engine();
            Engine engineThree = new Engine();
            return new List<Engine>() { engineOne, engineTwo, engineThree };
        }

        [TestMethod]
        public void GetTransmissions_Should_ReturnAListOfBrakes()
        {
            _componentRepositoryMock.Setup(o => o.GetTransmissions()).Returns(SetUpGetTransmissionsMock());
            List<Transmission> result = _testee.GetTransmissions();
            result.Count.ShouldBe(3);

            int currentComponentCost = result[0].Cost;
            foreach (Transmission transmission in result)
            {
                transmission.Cost.ShouldBeGreaterThanOrEqualTo(currentComponentCost);
                currentComponentCost = transmission.Cost;
            }
        }

        private List<Transmission> SetUpGetTransmissionsMock()
        {
            Transmission transmissionOne = new Transmission();
            Transmission transmissionTwo = new Transmission();
            Transmission transmissionThree = new Transmission();
            return new List<Transmission>() { transmissionOne, transmissionTwo, transmissionThree };
        }

        [TestMethod]
        public void GetComponentById_Should_ReturnAppropriateComponent()
        {
            _componentRepositoryMock.Setup(o => o.GetVehicleById(2)).Returns(SetUpGetVehicleByIdMock(2));
            _componentRepositoryMock.Setup(o => o.GetEngineById(2)).Returns(SetUpGetEngineByIdMock(2));
            _componentRepositoryMock.Setup(o => o.GetTransmissionById(2)).Returns(SetUpGetTransmissionByIdMock(2));
            _componentRepositoryMock.Setup(o => o.GetBrakesById(2)).Returns(SetUpGetBrakesByIdMock(2));
            _componentRepositoryMock.Setup(o => o.GetWheelsById(2)).Returns(SetUpGetWheelsByIdMock(2));

            Vehicle vehicleResult = _testee.GetVehicleById(2);
            Engine engineResult = _testee.GetEngineById(2);
            Brakes brakesResult = _testee.GetBrakesById(2);
            Transmission transmissionResult = _testee.GetTransmissionById(2);
            Wheels wheelsResult = _testee.GetWheelsById(2);

            vehicleResult.Id.ShouldBe(2);
            engineResult.Id.ShouldBe(2);
            brakesResult.Id.ShouldBe(2);
            transmissionResult.Id.ShouldBe(2);
            wheelsResult.Id.ShouldBe(2);
        }

        private Vehicle SetUpGetVehicleByIdMock(int id)
        {
            return new Vehicle() { Id = id };
        }
        private Engine SetUpGetEngineByIdMock(int id)
        {
            return new Engine() { Id = id };
        }
        private Brakes SetUpGetBrakesByIdMock(int id)
        {
            return new Brakes() { Id = id };
        }
        private Wheels SetUpGetWheelsByIdMock(int id)
        {
            return new Wheels() { Id = id };
        }
        private Transmission SetUpGetTransmissionByIdMock(int id)
        {
            return new Transmission() { Id = id };
        }

    }
}

